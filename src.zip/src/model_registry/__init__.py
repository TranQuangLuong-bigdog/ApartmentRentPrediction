"""Model registry package."""

